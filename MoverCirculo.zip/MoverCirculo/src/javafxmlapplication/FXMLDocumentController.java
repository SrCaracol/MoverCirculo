/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import static javafxmlapplication.Utils.*;



public class FXMLDocumentController implements Initializable {
    @FXML
    private GridPane grid;
    @FXML
    private Circle bola;
    
    private double sceneX;
    private double sceneY;
    @FXML
    private ColorPicker color;
    @FXML
    private ToggleButton rellenoTB;
    @FXML
    private Slider rSlider;
    
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        bola.radiusProperty().bind(Bindings.min(grid.widthProperty().divide(10).add(-2),grid.heightProperty().divide(10).add(-2)));
        bola.strokeProperty().bind(color.valueProperty());
        bola.fillProperty().bind(color.valueProperty());
    }    



    @FXML
    private void moverACelda(MouseEvent event) {
        sceneX = event.getSceneX();
        sceneY = event.getSceneY();
        grid.setConstraints(bola, columnCalc(grid, sceneX), rowCalc(grid, sceneY));
    }

    @FXML
    private void soltaBola(MouseEvent event) {
        bola.setTranslateX(0);
        bola.setTranslateY(0);
        moverACelda(event);
    }

    @FXML
    private void arrastraBola(MouseEvent event) {
        bola.setTranslateX(event.getSceneX()-sceneX);
        bola.setTranslateY(event.getSceneY()-sceneY);
    }

    @FXML
    private void polsaBola(MouseEvent event) {
        sceneX = event.getSceneX();
        sceneY = event.getSceneY();
    }

    @FXML
    private void teclaPolsada(KeyEvent event) {
    }

    @FXML
    private void rellenoCambiar(ActionEvent event) {
        if(rellenoTB.isSelected()){
            bola.fillProperty().unbind();
            bola.setFill(Color.TRANSPARENT);       
        }
        else
            bola.fillProperty().bind(color.valueProperty());
    }

    @FXML
    private void radioBola(MouseEvent event) {
       if(rSlider.isValueChanging()){
        bola.radiusProperty().unbind();
        bola.radiusProperty().bind(rSlider.valueProperty());
       }else{ bola.radiusProperty().bind(Bindings.min(grid.widthProperty().divide(10).add(-2),grid.heightProperty().divide(10).add(-2)));}
    }
}
